<?php

namespace App\Http\Controllers;

use App\BillDetailExtra;
use Illuminate\Http\Request;

class BillDetailExtraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BillDetailExtra  $billDetailExtra
     * @return \Illuminate\Http\Response
     */
    public function show(BillDetailExtra $billDetailExtra)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BillDetailExtra  $billDetailExtra
     * @return \Illuminate\Http\Response
     */
    public function edit(BillDetailExtra $billDetailExtra)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BillDetailExtra  $billDetailExtra
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BillDetailExtra $billDetailExtra)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BillDetailExtra  $billDetailExtra
     * @return \Illuminate\Http\Response
     */
    public function destroy(BillDetailExtra $billDetailExtra)
    {
        //
    }
}
